﻿using APIMongo_Peliculas.Models;
using APIMongo_Peliculas.Service;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace APIMongo_Peliculas.Controllers
{
	[Route("api/movies")]
	[ApiController]
	public class MovieApiController : ControllerBase
	{
		private readonly MovieService _movieService;

        public MovieApiController(MovieService movieService)
        {
            _movieService = movieService;
        }

        // GET: api/movies
        [HttpGet]
		public async Task<List<Movie>> Get()
		{
			return await _movieService.GetAsync();
		}

		// GET api/movies/{id}
		[HttpGet("{id:length(24)}")]
		public async Task<ActionResult<Movie>> Get(string id)
		{
			var movie = await _movieService.GetAsync(id);

			if (movie == null)
			{
				return NotFound();
			}

			return movie;
		}

		// POST api/movies
		[HttpPost]
		public async Task<IActionResult> Post(Movie movie)
		{
			await _movieService.CreateAsync(movie);

			return CreatedAtAction(nameof(Get), new { id = movie.Id }, movie);
		}

		// PUT api/<MovieController>/5
		[HttpPut("{id:length(24)}")]
		public async Task<IActionResult> update(string id, Movie updatedMovie)
		{
			var movie = _movieService.GetAsync(id);

			if(movie == null)
			{
				return NotFound();
			}

			await _movieService.UpdateAsync(id, updatedMovie);

			return NoContent();
		}

		// DELETE api/<MovieController>/5
		[HttpDelete("{id}")]
		public async Task<IActionResult> Delete(string id)
		{
			var movie = await _movieService.GetAsync(id);

			if (movie is null)
			{
				return NotFound();
			}

			await _movieService.RemoveAsync(id);
			return NoContent();
		}
	}
}
